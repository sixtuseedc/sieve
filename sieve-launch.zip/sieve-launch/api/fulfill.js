// /api/fulfill.js
// Fully automated lead-list pipeline, triggered by webhook.js after payment:
//   1. Find real businesses matching the buyer's industry/region (OpenStreetMap
//      Overpass API — free, no key, no request cap).
//   2. For each business with a website, look up emails via Hunter.io's free
//      tier (25 lookups/month — see the cap note at the bottom of this file).
//   3. Email the compiled list straight to the buyer via Resend.
//
// This file does the actual "no manual work" automation. webhook.js calls
// fulfillOrder() once a checkout.session.completed event comes in.

import { Resend } from 'resend';
const resend = new Resend(process.env.RESEND_API_KEY);

const OVERPASS_URL = 'https://overpass-api.de/api/interpreter';
const HUNTER_URL = 'https://api.hunter.io/v2/domain-search';

// Map a free-text industry into an OpenStreetMap tag query. OSM organizes
// businesses by tags, not keywords, so this is a small lookup table covering
// common cases, with a generic fallback ("name" text search) for anything else.
function industryToOverpassFilter(industry) {
  const i = industry.toLowerCase();
  const map = {
    'gym': 'leisure=fitness_centre',
    'fitness': 'leisure=fitness_centre',
    'restaurant': 'amenity=restaurant',
    'cafe': 'amenity=cafe',
    'coffee': 'amenity=cafe',
    'salon': 'shop=hairdresser',
    'dentist': 'amenity=dentist',
    'lawyer': 'office=lawyer',
    'law firm': 'office=lawyer',
    'real estate': 'office=estate_agent',
    'accountant': 'office=accountant',
    'auto repair': 'shop=car_repair',
    'mechanic': 'shop=car_repair',
    'bakery': 'shop=bakery',
    'florist': 'shop=florist',
    'bookstore': 'shop=books',
    'clothing': 'shop=clothes',
    'pet': 'shop=pet',
    'photography': 'shop=photo',
    'hotel': 'tourism=hotel',
  };
  for (const key in map) {
    if (i.includes(key)) return map[key];
  }
  return null; // signals "use generic name search" fallback
}

async function findBusinesses(industry, region) {
  const filter = industryToOverpassFilter(industry);

  // Overpass QL: search by tag if we recognized the industry, otherwise
  // fall back to matching the industry words against business names.
  const tagClause = filter
    ? `node[${filter}]["website"]${region ? `(area.searchArea)` : ''};`
    : `node["shop"]["website"]["name"~"${industry.replace(/"/g, '')}",i]${region ? `(area.searchArea)` : ''};`;

  const areaClause = region
    ? `area[name="${region.replace(/"/g, '')}"]->.searchArea;`
    : '';

  const query = `
    [out:json][timeout:25];
    ${areaClause}
    (
      ${tagClause}
    );
    out center 60;
  `;

  const res = await fetch(OVERPASS_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: query,
  });

  if (!res.ok) throw new Error(`Overpass request failed: ${res.status}`);
  const data = await res.json();

  return (data.elements || [])
    .map((el) => ({
      name: el.tags?.name || 'Unknown business',
      website: el.tags?.website || el.tags?.['contact:website'],
    }))
    .filter((b) => b.website)
    .map((b) => ({ ...b, domain: cleanDomain(b.website) }))
    .filter((b) => b.domain);
}

function cleanDomain(url) {
  try {
    const u = new URL(url.startsWith('http') ? url : `https://${url}`);
    return u.hostname.replace(/^www\./, '');
  } catch {
    return null;
  }
}

async function enrichWithHunter(domain) {
  const url = `${HUNTER_URL}?domain=${encodeURIComponent(domain)}&api_key=${process.env.HUNTER_API_KEY}&limit=3`;
  const res = await fetch(url);
  const data = await res.json();

  // Hunter returns 429/403 once the free monthly quota (25 requests) is used up.
  if (res.status === 429 || res.status === 403) {
    return { quotaExceeded: true, emails: [] };
  }
  if (!res.ok || !data.data) return { quotaExceeded: false, emails: [] };

  const emails = (data.data.emails || []).map((e) => e.value).filter(Boolean);
  return { quotaExceeded: false, emails };
}

export async function fulfillOrder({ industry, region, buyerEmail, plan, requestedCount }) {
  const businesses = await findBusinesses(industry, region);

  const results = [];
  let quotaHit = false;

  for (const biz of businesses) {
    if (results.length >= requestedCount) break;
    if (quotaHit) break;

    const { quotaExceeded, emails } = await enrichWithHunter(biz.domain);
    if (quotaExceeded) { quotaHit = true; break; }

    emails.forEach((email) => {
      if (results.length < requestedCount) {
        results.push({ business: biz.name, domain: biz.domain, email });
      }
    });
  }

  const csv = ['business,domain,email', ...results.map(r => `"${r.business}","${r.domain}","${r.email}"`)].join('\n');

  await resend.emails.send({
    from: 'orders@yourdomain.com',
    to: buyerEmail,
    subject: `Your Sieve list — ${industry}${region ? `, ${region}` : ''}`,
    text: quotaHit && results.length < requestedCount
      ? `We found ${results.length} of your ${requestedCount} requested leads before hitting this month's lookup limit. The rest of your order will be completed and sent as a follow-up once the limit resets — no action needed from you.`
      : `Here are your ${results.length} leads for "${industry}". CSV attached below.`,
    attachments: [{ filename: 'leads.csv', content: Buffer.from(csv).toString('base64') }],
  });

  // Tell yourself too, so "checking for malfunctions" actually has something to check.
  await resend.emails.send({
    from: 'orders@yourdomain.com',
    to: process.env.OWNER_EMAIL,
    subject: `[fulfillment] ${industry} — ${results.length}/${requestedCount} delivered${quotaHit ? ' (HUNTER QUOTA HIT)' : ''}`,
    text: `Plan: ${plan}\nBuyer: ${buyerEmail}\nDelivered: ${results.length}/${requestedCount}\nHunter quota exceeded: ${quotaHit}`,
  });

  return { delivered: results.length, quotaHit };
}

/*
  REALITY CHECK — read this before you launch:

  - Hunter.io's free tier is 25 lookups/month, total, across ALL orders.
    A single 100-lead order can burn through that in one run. Once it's gone,
    every order that month silently returns partial/empty results until the
    buyer email above (the "partial delivery" one) fires — that's the
    "malfunctioning" you'll be checking for.
  - OpenStreetMap's business/website data is incomplete and inconsistent by
    region — some industries and areas will return very few results.
  - This is genuinely free and genuinely automated, but at low volume. The
    moment you're selling more than a handful of orders a month, Hunter's
    paid tier ($49/mo for 1,000 lookups) or Apollo.io's API becomes the
    realistic next step — at that point this same file just needs the
    HUNTER_API_KEY swapped for a paid one, nothing else changes.
*/
