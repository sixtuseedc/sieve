// /api/webhook.js
// Stripe calls this URL automatically when a payment succeeds. This is where
// fulfillment kicks off. For launch day, that just means: email YOU the order
// details so you can build the list by hand and send it to the customer.
// Later, swap the emailOrderToSelf() call for an automated pipeline
// (Apollo/PDL lookup -> verify -> email the buyer directly).

import Stripe from 'stripe';
import { Resend } from 'resend';
import { fulfillOrder } from './fulfill.js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const resend = new Resend(process.env.RESEND_API_KEY);

// Each plan id maps to how many leads that purchase is owed.
const PLAN_VOLUMES = {
  'one-100': 100,
  'one-500': 500,
  'one-1000': 1000,
  'weekly-50': 50,
  'monthly-200': 200,
  'monthly-500': 500,
};

// Vercel needs the raw request body to verify the Stripe signature,
// so we disable the default JSON body parser for this route.
export const config = { api: { bodyParser: false } };

function buffer(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const sig = req.headers['stripe-signature'];
  const rawBody = await buffer(req);

  let event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const { plan, industry, region, mode } = session.metadata || {};
    const buyerEmail = session.customer_details?.email || session.customer_email;
    const requestedCount = PLAN_VOLUMES[plan] || 100;

    try {
      // This is the "no manual work" part: discovery + enrichment + delivery
      // all happen here automatically. See fulfill.js for the full pipeline
      // and its honest limits (Hunter's free 25/month cap, mainly).
      await fulfillOrder({ industry, region, buyerEmail, plan, requestedCount });
    } catch (err) {
      console.error('Automated fulfillment failed:', err);
      // Fall back to notifying you so a failed run doesn't vanish silently.
      try {
        await resend.emails.send({
          from: 'orders@yourdomain.com',
          to: process.env.OWNER_EMAIL,
          subject: `[FULFILLMENT FAILED] ${plan} — ${industry}`,
          text: `Automated fulfillment threw an error for this order. Buyer: ${buyerEmail}. Error: ${err.message}\n\nThis order needs manual follow-up.`,
        });
      } catch (innerErr) {
        console.error('Even the failure notification failed:', innerErr);
      }
    }
  }

  // Handles cancellations on subscription plans so you know to stop fulfilling.
  if (event.type === 'customer.subscription.deleted') {
    console.log('Subscription cancelled:', event.data.object.id);
  }

  return res.status(200).json({ received: true });
}
