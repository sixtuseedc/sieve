# Launching Sieve — step by step

This gets you from "files on a laptop" to "live site that can take real
payments" today. None of these steps can be done on your behalf — they all
require your own identity/business info, which only you can provide.

## 1. Put the code in a GitHub repo
- Create a free GitHub account if you don't have one.
- Create a new repo, e.g. `sieve`.
- Upload everything from this folder (`index.html`, the `api/` folder,
  `package.json`) into it.

## 2. Create your Stripe account
- Go to stripe.com → Sign up.
- You'll need: legal name/business name, bank account (for payouts), and a
  government ID for verification. This is what makes money land in YOUR
  account — there's no way around Stripe's identity check, it's a banking
  regulation thing, not a Stripe preference.
- While in test mode (default for a brand-new account) you can do everything
  below safely with fake card numbers — switch to live mode only once you're
  ready to take real money.
- Go to Developers → API keys → copy the **Secret key**. This goes in
  `STRIPE_SECRET_KEY`.

## 3. Deploy to Vercel
- Go to vercel.com → sign up with your GitHub account.
- "Add New Project" → pick your `sieve` repo → Deploy.
- It'll fail the first time because env vars aren't set yet — that's expected.
- Go to Project → Settings → Environment Variables and add everything from
  `.env.example` (real values, not the placeholders).
- For `SITE_URL`, use the `https://your-project.vercel.app` URL Vercel gave you.
- Redeploy (Deployments tab → ⋯ → Redeploy).

## 4. Connect the Stripe webhook
This is the piece that tells your backend "a payment just succeeded."
- In Stripe Dashboard → Developers → Webhooks → Add endpoint.
- Endpoint URL: `https://your-project.vercel.app/api/webhook`
- Select event: `checkout.session.completed`
- After creating it, copy the **Signing secret** shown on that page →
  paste into `STRIPE_WEBHOOK_SECRET` in Vercel → redeploy.

## 5. Set up order emails and the data API
- Go to resend.com → sign up free → verify a sending domain (or use their
  test domain while you set things up).
- Create an API key → put it in `RESEND_API_KEY`.
- Go to hunter.io → sign up free (no card required) → Dashboard → API → copy
  your key → put it in `HUNTER_API_KEY`. This is the free tier: 25 email
  lookups per month, shared across every order that month.
- Set `OWNER_EMAIL` to wherever you want order + failure notifications to land.

## 6. Test it for real
- With Stripe still in test mode, place a test order on your live site using
  card number `4242 4242 4242 4242`, any future expiry, any CVC.
- Within a few seconds you should get an email at the buyer address with a
  `leads.csv` attached, and a separate email at `OWNER_EMAIL` confirming how
  many leads were delivered.
- Try an industry like "gym," "restaurant," or "dentist" first — those map to
  recognized OpenStreetMap categories and return results reliably. Unusual
  industries fall back to a name-text search and may return very little —
  that's a real limitation of free map data, not a bug.

## 7. Go live
- Flip Stripe from test mode to live mode (top-left toggle in the dashboard).
- Swap the `sk_test_...` key for the `sk_live_...` key in Vercel's env vars.
- Re-add the webhook endpoint under live mode too (test and live mode have
  separate webhooks) and update `STRIPE_WEBHOOK_SECRET` again.
- Redeploy. You're live.

## What "no work besides checking for malfunctions" actually means here
Every order is fully automated end to end: Stripe takes payment → webhook
fires → the backend finds real businesses for that industry via OpenStreetMap
→ looks up emails via Hunter.io → emails the CSV straight to the buyer. You
don't touch any of that.

What you DO need to check periodically:
- **Hunter's 25/month free cap.** Past that, buyers get a "partial delivery"
  email instead of a full list, and you get a flagged notification. This will
  happen fast if you get real volume — at that point, upgrading Hunter
  ($49/mo for 1,000 lookups) is a one-line env var change, nothing else in
  the code needs to change.
- **The `[FULFILLMENT FAILED]` emails.** If OpenStreetMap or Hunter is down,
  or an industry returns zero matches, you'll get one of these instead of
  silence — that's the signal to step in manually for that one order.
- **Stripe Dashboard → Payments**, just to glance at occasionally and confirm
  charges are going through cleanly.

## One honest caveat
A backend that "skips" identity-checked payments to deposit money "directly"
isn't something that exists safely — every legitimate path (Stripe, PayPal,
etc.) requires you personally to be verified before money reaches your bank.
That's not a limitation I'm imposing; it's how banking compliance works
everywhere.

Similarly, "free" lead data has a real ceiling — Hunter's generous free tier
is what makes this possible at $0 running cost, but it's built for low
volume. If this business takes off, the data cost stops being free; that's
normal and the pricing already has margin built in for that day.
